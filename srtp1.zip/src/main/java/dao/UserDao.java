package dao;

import com.example.srtp1.cdata.User;

import java.util.List;

public interface UserDao {
    int addUser(User user);
    List<User> queryByUsername(String user_name);
}
