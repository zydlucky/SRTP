package com.example.srtp1.service.impl;

import com.example.srtp1.cdata.*;
import com.example.srtp1.service.UserService;
import dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Map;

public class UserServletImpl implements UserService {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    UserDao userDao;

    @Override
    public void LoginUser(User user ) {
        String sql="select * from t_user where username=? and password=?";
        jdbcTemplate.update(sql,user.getUser_id(),user.getUser_name(),user.getUser_password(),user.getUser_phone());
    }

    @Override
    public void registerUser(User user) {
        String sql="insert into User(user_id,user_name,user_password,user_phone) values(null,?,?,?,?,?)";
        jdbcTemplate.update(sql,user.getUser_name(),user.getUser_password(),user.getUser_phone());
    }

    //修改用户基本信息
    @Override
    public void changeUser_basic(User user) {
        String sql="update User set user(user_name,user_phone,user_num) values (?,?,?) where user_id = ?";
        jdbcTemplate.update(sql,user.getUser_name(),user.getUser_phone(),user.getUser_num());
    }

    //修改用户密码
    @Override
    public void changeUser_password(User user) {
        String sql="update User set user_password = ? where user_id = ?";
        jdbcTemplate.update(sql,user.getUser_password());
    }

    //管理员批量导入
    @Override
    public void admin_import(User user) {

    }

    //认证身份
    @Override
    public void identity(User user) {

    }

    //登录用户(输入name，password，返回相关数据)
    @Override
    public int addUser(String user_name, String user_password, String user_phone){
        User user = new User(user_name, user_password,user_phone);
        int isadd = userDao.addUser(user);
        return isadd;
    }

    @Override
    public List<User> queryByUsername(String user_name){
        List<User> userList = userDao.queryByUsername(user_name);
        return userList;
    }
}
