package com.example.srtp1.service;

import com.example.srtp1.cdata.Competiton;

import java.sql.SQLException;
import java.util.List;

public interface CompetitionService {
    void hotCom(Competiton competiton);  //热点竞赛展示
    void keysearCom(Competiton competiton);  //关键词搜索
    void datesearCom(Competiton competiton); //日期搜索
    void addCom(Competiton competiton);  //发布竞赛
    void deleteCom(int Competion_id);    //删除竞赛
    void updateCom(Competiton competiton);  //修改竞赛
    void idsignCom(int Competion_id);    //用竞赛id查询报名信息
    void idwardCom(int Competion_id);    //用竞赛id查询获奖信息
    List<Competiton> ComFindAll() throws SQLException;
}
