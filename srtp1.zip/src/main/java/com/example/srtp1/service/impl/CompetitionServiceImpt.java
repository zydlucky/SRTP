package com.example.srtp1.service.impl;

import com.example.srtp1.cdata.Competiton;
import com.example.srtp1.service.CompetitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.SQLException;
import java.util.List;

public class CompetitionServiceImpt implements CompetitionService {
    @Autowired
    private JdbcTemplate jdbcTemplate;

//    @Override
    public void addCom(Competiton competiton){
        String sql = "insert into Competition(Competion_id,Competition_main_name,Competition_manager,Start_date,End_date,Competition_sub_name,Competition_level,Competition_subject,Competition_category,Competition_information,sign_up_start,sign_up_end,preliminary_start,preliminary_end,repecharge_start,repecharge_end,finals_start,finals_end) values(null,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,competiton.getCompetition_main_name(),competiton.getCompetition_manager(),competiton.getStart_date(),competiton.getEnd_date(),competiton.getCompetition_sub_name(),competiton.getCompetition_level(),competiton.getCompetition_subject(),competiton.getCompetition_category(),competiton.getCompetition_information(),competiton.getSign_up_start(),competiton.getSign_up_end(),competiton.getPreliminary_start(),competiton.getPreliminary_end(),competiton.getRepecharge_start(),competiton.getRepecharge_end(),competiton.getFinals_start(),competiton.getFinals_end());
    }

//    @Override
    public void deleteCom(int Competition_id) {
        String sql="delete * in Competition where Competition_id=?";
        jdbcTemplate.update(sql,Competition_id);
    }

//    @Override
    public void updateCom(Competiton competiton){
//        String sql="update Competiton set ... where Competiton_id='"+Competiton.getCompetiton_id()+"'";
//        jdbcTemplate.update(sql,Competiton.get...);
    }

//    @Override
    public List<Competiton> ComFindAll() throws SQLException{
        String sql = "select * from Competition";
        return jdbcTemplate.query(sql, new BeanPropertyRowMapper<Competiton>(Competiton.class));
    }
}
