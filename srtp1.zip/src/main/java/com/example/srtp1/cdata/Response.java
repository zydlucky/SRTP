package com.example.srtp1.cdata;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data   //添加getter/setter
@NoArgsConstructor     //添加无参构造器
@AllArgsConstructor     //添加全参构造器

public class Response {
    String msg;
    int code;
    Boolean isSuc = true;
}
