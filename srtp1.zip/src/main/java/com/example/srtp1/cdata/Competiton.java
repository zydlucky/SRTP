package com.example.srtp1.cdata;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)

public class Competiton<String> {
    @TableId(value = "Competition_id",type = IdType.AUTO)
    private int Competion_id;
    private String Competition_main_name;
    private String Competition_manager;
    private String Start_date;
    private String End_date;
    private String Competition_sub_name;  //竞赛副标题
    private String Competition_level;     //等级
    private String Competition_subject;   //科目
    private String Competition_category;  //竞赛类别
    private String Competition_information;
    private String sign_up_start;         //报名开始时间
    private String sign_up_end;
    private String preliminary_start;     //初赛开始时间
    private String preliminary_end;
    private String repecharge_start;      //复赛开始时间
    private String repecharge_end;
    private String finals_start;          //决赛开始时间
    private String finals_end;
    private String attachment1;           //附件1
    private String attachment2;
    private String attachment3;
}
