package com.example.srtp1.controller;

import com.example.srtp1.service.UserService;
import dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import com.example.srtp1.cdata.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.lang.reflect.Member;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    @Resource
    private UserService service;
    private JdbcTemplate jdbcTemplate;

    //注册用户(name,password,phone)
    @RequestMapping(value = "register", method = RequestMethod.POST)
    public Response register(@RequestBody Map<String, String> person) {
//        String sql="insert into User(user_id,user_name,user_password,user_e-mail,user_phone,user_picture) values(null,?,?,?,?,?)";
//        jdbcTemplate.update(sql,user.getUser_name(),user.getUser_password(),user.getUser_email(),user.getUser_phone(),user.getUser_picture());
        String user_name = person.get("user_name");
        String user_password = person.get("user_password");
        String user_phone = person.get("user_phone");
        //1.判断用户名、密码、手机号是否为空
        if (user_name != null && user_password != null && user_phone != null) {
            List<User> users = service.queryByUsername(user_name);
            //2.判断是否有重复用户名
            if (user_name != null && user_name.length() > 0) {
                return new Response("注册失败，用户名重复,请更换", 700, true);
            } else if (user_phone != null && user_phone.length() > 0) {
                return new Response("注册失败，电话号码重复,请更换", 701, true);
            } else {
                int count = service.addUser(user_name, user_password, user_phone);
                if (count > 0) {
                    //3.没有重复用户名，注册成功
                    return new Response("注册成功", 666, true);
                } else {
                    return new Response("注册失败", 703, true);
                }
            }
        } else {
            return new Response("注册失败，请检查用户名、密码、手机号是否为空", 702, true);
        }
    }

    //用户登录
    @RequestMapping(value = "login", method = RequestMethod.POST)
    public Response login(@RequestBody Map<String, String> User, Member member, HttpServletRequest request) {
        String user_name = User.get("user_name");
        String user_password = User.get("user_password");
        String user_phone = User.get("user_phone");
        //判断是用户名还是手机号的正则表达式
//        String ph = "^((13[0-9])|(15[^4,\\\\D])|(17[0-9])|(18[0,5-9]))\\\\d{8}$";
//        HttpSession session = request.getSession();
//        if (user_phone.matches(ph)) {  //手机号登陆
//            map.put("user_phone", user_phone);
//            map.put("user_password", user_password);
//            Member ph_member = null;
//            ph_member = memberDao.selectMemberByPhoneNumber(map);
//            if (ph_member == null) {
//                return new Response("登录失败：电话或密码错误", 703, false);
//            }else {
//                return new Response("登录失败：电话和密码不能为空", 704, false);
//            }
//        } else {
            if (user_name != null && user_password != null) {
                List<User> user = service.queryByUsername(user_name);
                if (user_name.length() == 0) {
                    return new Response("登录失败：用户名不存在", 701, false);
                } else {
                    if (user.get(0).getUser_password().equals(user_password)) {
                        return new Response("登录成功", 666, true);
                    } else {
                        return new Response("登录失败：用户名或密码错误", 700, false);
                    }
                }
            } else {
                return new Response("登录失败：用户名和密码不能为空", 702, false);
            }
        }
//    }

    //修改用户基本信息
    @RequestMapping(value = "chabasic", method = RequestMethod.POST)
    public boolean changeUser_basic(User user) {
        service.changeUser_basic(user);
        return true;
    }

    //修改密码
    @RequestMapping(value = "chapass", method = RequestMethod.POST)
    public boolean changeUser_password(User user) {
        service.changeUser_password(user);
        return true;
    }

    @GetMapping(value = "bulkimport")  //管理员批量导入
    public boolean admin_import(@RequestBody User user){
        service.admin_import(user);
        return true;
    }
    @RequestMapping(value = "identity")  //身份认证
    public boolean identity(@RequestBody User user){
        service.identity(user);
        return true;
    }
}
