package com.example.srtp1.controller;

import com.example.srtp1.cdata.Competiton;
import com.example.srtp1.service.CompetitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;
import java.util.List;

@RestController
@RequestMapping("/com")

public class CompetitionController {
    @Autowired
    @Resource private CompetitionService service;

    @PostMapping(value = "add")       //发布竞赛
    public boolean addCom(@RequestBody Competiton competiton, HttpServletResponse response){
        service.addCom(competiton);
        return true;
    }

    @GetMapping(value = "delete")    //删除竞赛
    public void deleteCom(@RequestBody MysqlxDatatypes.Scalar.String Competition_id, HttpServletResponse response){
        System.out.println(Competition_id);
        service.deleteCom(0);
    }

    @RequestMapping(value = "update") //修改
    public void updateCom(@RequestBody Competiton competiton, HttpServletResponse response){
        service.updateCom(competiton);
    }

    @RequestMapping(value = "findall") //无搜索
    public List<Competiton> findAllCom(HttpServletResponse response) throws SQLException {
        return service.ComFindAll();
    }
}
