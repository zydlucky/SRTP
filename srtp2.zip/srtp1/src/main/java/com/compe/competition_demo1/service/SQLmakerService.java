package com.compe.competition_demo1.service;

import java.sql.SQLException;

public interface SQLmakerService {
    void createall() throws SQLException;
    void deleteall() throws SQLException;
}
