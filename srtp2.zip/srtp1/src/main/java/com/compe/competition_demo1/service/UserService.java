package com.compe.competition_demo1.service;

import com.compe.competition_demo1.cdata.usersth.Chabasic.chabasic_out;
import com.compe.competition_demo1.cdata.usersth.Chabasic.userChabasic;
import com.compe.competition_demo1.cdata.usersth.Chapass.chapass_out;
import com.compe.competition_demo1.cdata.usersth.Chapass.userChapass;
import com.compe.competition_demo1.cdata.usersth.Identity.identity_out;
import com.compe.competition_demo1.cdata.usersth.Identity.userIdentity;
import com.compe.competition_demo1.cdata.usersth.Register.register_out;
import com.compe.competition_demo1.cdata.usersth.Register.userRegister;
import com.compe.competition_demo1.cdata.usersth.User;
import com.compe.competition_demo1.cdata.usersth.Login.login_out;
import com.compe.competition_demo1.cdata.usersth.Login.userLogin;

/*用户类User的功能接口*/
public interface UserService {
    public login_out LoginUser(userLogin user_login);//用户登录
    public register_out registerUser(userRegister user_register);         //用户注册
    public chabasic_out changeUser_basic(userChabasic user_chabasic);  //用户修改基本信息
    public chapass_out changeUser_password(userChapass user_chapass);
    public void admin_import(User user);  //管理员批量导入
    public identity_out identity(userIdentity user_identity);    //修改用户身份
}

